MY SAVINGS - Android project

Fitur:
- Target 52 minggu: Rp23.400.000
- Minggu ganjil: Rp400.000
- Minggu genap: Rp500.000
- Checklist setoran, progress, saldo terkumpul, sisa target
- Progres tersimpan otomatis secara lokal di perangkat

Cara membuat APK:
1. Instal Android Studio di komputer.
2. Ekstrak folder MySavingsAndroid.
3. Android Studio > Open > pilih folder MySavingsAndroid.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK akan muncul di app/build/outputs/apk/debug/app-debug.apk.

Catatan: Paket ini adalah source project Android, bukan file APK yang sudah dikompilasi.
Memerlukan Android Studio dan koneksi internet pertama kali untuk mengunduh Gradle/Android SDK yang diperlukan.
